import argparse
import json

from analyser.reqs import project_import_modules, file_import_modules

parser = argparse.ArgumentParser(description='Get the used modules')
parser.add_argument('--folder')
parser.add_argument('--file')

args = parser.parse_args()

if args.folder is not None:
    modules, try_imports, local_mods = project_import_modules(args.folder, False)
    print(json.dumps({
        "modules": modules,
        "try_imports": list(try_imports),
        "local_mods": local_mods
    }))


elif args.file is not None:
    with open(args.file, 'rb') as f:
        modules, try_imports = file_import_modules(args.file, f.read())
        print(json.dumps({
            "modules": modules,
            "try_imports": list(try_imports)
        }))
